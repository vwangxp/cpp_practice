#include <fmt/core.h>

#include <iostream>

int main() {

    fmt::print("hello, {}!\n", "gcc");
}